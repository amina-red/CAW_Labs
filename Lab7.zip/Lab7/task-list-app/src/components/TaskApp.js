// TaskApp.js
import React, { useState } from 'react';
import TaskList from './TaskList';

const TaskApp = () => {
  const [tasks, setTasks] = useState([
    { id: 1, description: 'Task 1: small Description...', subtasks: [] },
    { id: 2, description: 'Task 2: small Description...', subtasks: [] },
    { id: 3, description: 'Task 3: small Description...', subtasks: [] },
  ]);

  return (
    <div>
      {tasks.map((task) => (
        <TaskList key={task.id} task={task} tasks={tasks} setTasks={setTasks} />
      ))}
    </div>
  );
};

export default TaskApp;
