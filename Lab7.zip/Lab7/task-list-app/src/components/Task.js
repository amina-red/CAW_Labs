

import React, { useState } from 'react';

function Task({ task, deleteTask }) {
  const [subTasks, setSubTasks] = useState([]);
  const [isTaskOpen, setIsTaskOpen] = useState(false);
  const [newSubTask, setNewSubTask] = useState('');

  const addSubTask = () => {
    if (newSubTask.trim() !== '') {
      const newSubTaskObject = {
        id: subTasks.length + 1,
        title: newSubTask,
        done: false,
      };
      setSubTasks([...subTasks, newSubTaskObject]);
      setNewSubTask(''); 
    }
  };

  const markSubTaskDone = (subTaskId) => {
    const updatedSubTasks = subTasks.map((subTask) =>
      subTask.id === subTaskId ? { ...subTask, done: true } : subTask
    );
    setSubTasks(updatedSubTasks);
  };

  return (
    <div className="task">
      <div onClick={() => setIsTaskOpen(!isTaskOpen)}>
        <span>{task.title}</span>
        <button className="button" onClick={() => deleteTask(task.id)}>
          X
        </button>
      </div>
      {isTaskOpen && (
        <div className="sub-tasks">
          {subTasks.map((subTask) => (
            <div key={subTask.id} className="sub-task">
              <span>{subTask.title}</span>
              {!subTask.done && (
                <button
                  className="button"
                  onClick={() => markSubTaskDone(subTask.id)}
                >
                  DONE
                </button>
              )}
            </div>
          ))}
          <div className="add-sub-task-container">
            <input
              type="text"
              value={newSubTask}
              onChange={(e) => setNewSubTask(e.target.value)}
              placeholder="Nouvelle sous-tâche"
            />
            <button
              className="button add-sub-task-button"
              onClick={addSubTask}
            >
              Ajouter
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default Task;
